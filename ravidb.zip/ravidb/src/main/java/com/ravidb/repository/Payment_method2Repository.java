package com.ravidb.repository;

import org.springframework.data.repository.CrudRepository;

import com.ravidb.beans.Payment_method2;

public interface Payment_method2Repository  extends CrudRepository<Payment_method2, String >{

}
