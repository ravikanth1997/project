package com.ravidb.repository;

import org.springframework.data.repository.CrudRepository;

import com.ravidb.beans.Billing_Details;

public interface Billing_DetailsRepository extends CrudRepository<Billing_Details, String>
{

}
