package com.ravidb.repository;

import org.springframework.data.repository.CrudRepository;

import com.ravidb.beans.Card;

public interface CardRepository extends CrudRepository<Card, String>
{

}
