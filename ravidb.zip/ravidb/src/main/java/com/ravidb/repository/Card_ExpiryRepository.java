package com.ravidb.repository;

import org.springframework.data.repository.CrudRepository;

import com.ravidb.beans.Card_Expiry;

public interface Card_ExpiryRepository extends CrudRepository<Card_Expiry, String>
{

}
