package com.ravidb.beans;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.beans.factory.annotation.Autowired;

@Entity
public class Card
{  
	@Id
	private String holder_Name;
	private String card_Type;
	private String card_Bin;
	private String last_Digits;
	public String getHolder_Name() {
		return holder_Name;
	}
	public void setHolder_Name(String holder_Name) {
		this.holder_Name = holder_Name;
	}
	public String getCard_Type() {
		return card_Type;
	}
	public void setCard_Type(String card_Type) {
		this.card_Type = card_Type;
	}
	public String getCard_Bin() {
		return card_Bin;
	}
	public void setCard_Bin(String card_Bin) {
		this.card_Bin = card_Bin;
	}
	public String getLast_Digits() {
		return last_Digits;
	}
	public void setLast_Digits(String last_Digits) {
		this.last_Digits = last_Digits;
	}
	@Override
	public String toString() {
		return "Card [holder_Name=" + holder_Name + ", card_Type=" + card_Type + ", card_Bin=" + card_Bin
				+ ", last_Digits=" + last_Digits + "]";
	}
	
}