package com.ravidb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ravidb.beans.Card;
import com.ravidb.beans.Card_Expiry;
import com.ravidb.repository.Card_ExpiryRepository;

@RestController
@RequestMapping("/card_expiry")
public class FourController 
{
	@Autowired
	private Card_ExpiryRepository repository;
	
	 @GetMapping("/readAll")
	 	public Iterable< Card_Expiry  > readAll()
	 	{
	 		 Iterable< Card_Expiry  > all  =repository.findAll();
	 		 return all;
	 	}
	

}
