package com.ravidb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ravidb.beans.Billing_Details;
import com.ravidb.beans.Card;
import com.ravidb.repository.CardRepository;

@RestController
@RequestMapping("/card")
public class ThirdController 
{
	@Autowired
	private CardRepository repository;
	
	
	 @GetMapping("/readAll")
	 	public Iterable<Card > readAll()
	 	{
	 		 Iterable<Card > all  =repository.findAll();
	 		 return all;
	 	}
	

}
