package com.ravidb.controller;



import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.ravidb.beans.Billing_Details;
import com.ravidb.beans.Card;
import com.ravidb.beans.Card_Expiry;
import com.ravidb.beans.Payment_method2;
import com.ravidb.beans.Return_Links;
import com.ravidb.repository.Billing_DetailsRepository;
import com.ravidb.repository.CardRepository;
import com.ravidb.repository.Card_ExpiryRepository;
import com.ravidb.repository.Payment_method2Repository;
import com.ravidb.repository.Return_LinksRepository;





@RestController
@RequestMapping("/payment1")
public class FirstController2 
{
	  @Autowired
      private Payment_method2Repository repository;
	  
	  @Autowired
		private Billing_DetailsRepository billingRepository;
		
		@Autowired
		private CardRepository cardRepository;
		
		@Autowired
		private Card_ExpiryRepository cardExpiryRepository;
		
		@Autowired
		private Return_LinksRepository returnlinksRepository;
		
    
		@GetMapping("/readAll")
		public String readAll() {
			Iterable<Payment_method2> all = repository.findAll();
			Gson gson = new Gson();
			String json = gson.toJson(all);

			JSONArray j1 = new JSONArray(json);
			JSONObject res = new JSONObject(j1.get(0).toString());

			Iterable<Billing_Details> billingResponse = billingRepository.findAll();

			json = gson.toJson(billingResponse);
			JSONObject billingJson = new JSONObject(new JSONArray(json).get(0).toString());
			res.put("BillingDetails", billingJson);

			// to get card

			Iterable<Card> cardResponse = cardRepository.findAll();

			json = gson.toJson(cardResponse);
			JSONObject cardJson = new JSONObject(new JSONArray(json).get(0).toString());
			// GET the card expiry
			Iterable<Card_Expiry> cardExpiry = cardExpiryRepository.findAll();

			json = gson.toJson(cardExpiry);
			JSONObject cardExpiryJson = new JSONObject(new JSONArray(json).get(0).toString());
			cardJson.put("caredExpiry", cardExpiryJson);
			
			
			res.put("card", cardJson);
			
			Iterable<Return_Links> returnlinks = returnlinksRepository.findAll();
			json=gson.toJson(returnlinks);
			res.put("returnlinks",new JSONArray(json));
			return res.toString();
  	

}
}
