package com.ravidb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ravidb.beans.Card_Expiry;
import com.ravidb.beans.Return_Links;
import com.ravidb.repository.Return_LinksRepository;

@RestController
@RequestMapping("/return_Links")
public class FiveController 
{
	
	@Autowired
	private Return_LinksRepository repository;
	
	@GetMapping("/readAll")
 	public Iterable<Return_Links> readAll()
 	{
 		 Iterable<  Return_Links   > all  =repository.findAll();
 		 return all;
 	}

}
