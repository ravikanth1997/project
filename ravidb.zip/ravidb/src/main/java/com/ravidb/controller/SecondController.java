package com.ravidb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ravidb.beans.Billing_Details;
import com.ravidb.beans.Payment_method2;
import com.ravidb.repository.Billing_DetailsRepository;
import com.ravidb.repository.Payment_method2Repository;

@RestController
@RequestMapping("/billing_Details ")
public class SecondController 
{
	 @Autowired
     private Billing_DetailsRepository repository;
     
    
     @GetMapping("/readAll")
 	public Iterable<Billing_Details > readAll()
 	{
 		 Iterable<Billing_Details > all  =repository.findAll();
 		 return all;
 	}


}
