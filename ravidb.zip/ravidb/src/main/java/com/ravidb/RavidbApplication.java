package com.ravidb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RavidbApplication {

	public static void main(String[] args) {
		SpringApplication.run(RavidbApplication.class, args);
	}

}
